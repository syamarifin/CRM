﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        #region Page_load
        protected void Page_Load(object sender, EventArgs e)
        { //Creating DataFolder if it is not exists
           string root = Server.MapPath("~/DataFolder/");
            if (!Directory.Exists(root))
            {

                Directory.CreateDirectory(root);

            }
        }
        #endregion

        #region Upload Button
        protected void Button1_Click(object sender, EventArgs e)
        {
            
            //delete files from direcroty 
            string[] filePaths = Directory.GetFiles(Server.MapPath("~/DataFolder/"));
            foreach (string filePath in filePaths)
                File.Delete(filePath);

            //folderupload
            if (FileUpload1.HasFiles)
            {
                foreach (var file in FileUpload1.PostedFiles)
                {

                    string filePath = Server.MapPath("~/DataFolder/" + System.IO.Path.GetFileName(file.FileName));
                    file.SaveAs(filePath);
                }
                string Pathi = Server.MapPath("~/DataFolder/");
              string sFileExt = "*.txt";
               
                LoadFilesFromPath(Pathi, sFileExt);
             


            }
            else
            {
                Response.Write("<script>alert('Please Select a Directory') </script>");
            }


        }
        #endregion

        #region Load FileName in Grid
        private void LoadFilesFromPath(string Path, string sFileExt)
        {
            GridDevDetails.Visible = true;
            try
            {
                DataTable dtFmt = new DataTable();
                DataTable dt = CreateDataTableFormat();
                if (System.IO.Directory.Exists(Path))
                {
                    String[] arFileList;
                    arFileList = Directory.GetFiles(Path, sFileExt);

                    for (int RowNo = 0; RowNo <= arFileList.Length - 1; RowNo++)
                    {
                        string[] strFolder = arFileList[RowNo].Split('\\');

                        string lstFileName = strFolder[strFolder.Length - 1];
                        DataRow dR = dt.NewRow();
                        dR["SlNo"] = RowNo + 1;
                        dR["FileName"] = lstFileName.Trim();

                        dt.Rows.Add(dR);
                    }
                }
                GridDevDetails.DataSource = dt;
                GridDevDetails.DataBind();


            }
            catch
            {
                throw new NotImplementedException();
            }

        }
        #endregion

        #region Datatable Creation
        private DataTable CreateDataTableFormat()
        {
            try
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("SlNo");
                dt.Columns.Add("FileName");
                return (dt);

            }
            catch
            {
                return null;
            }
        }
        #endregion

    }
}